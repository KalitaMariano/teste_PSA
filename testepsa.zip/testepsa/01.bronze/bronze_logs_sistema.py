# Databricks notebook source
#import o controle de de data
from pyspark.sql.functions import current_date,current_timestamp, expr

# COMMAND ----------

# MAGIC %pip install lxml

# COMMAND ----------

 #criação de variavel 
 database ="bronze"
 tabela = "logs_sistema"

# COMMAND ----------

import pandas as pd

# Caminho do arquivo no volume
path = "/Volumes/psa/bronze/logs/logs_sistema.html"

# Ler a(s) tabela(s) HTML
tables = pd.read_html(path)   # requer lxml instalado
df_html = tables[0]           # pega a primeira tabela

# Conferir dados
display(df_html)


# COMMAND ----------

# Converter pandas → Spark
df = spark.createDataFrame(df_html)

#tive que criar pois estava aparecendo schema not found

spark.sql("create database if not exists bronze")

# COMMAND ----------

#tive que fazer no bronze pois não savava na tabela

import unicodedata

def limpar_nome(col):
    col = ''.join(c for c in unicodedata.normalize('NFD', col)
                  if unicodedata.category(c) != 'Mn')  # remove acentos
    col = col.strip().replace(" ", "_").lower()        # troca espaços por _
    return col

df = df.toDF(*[limpar_nome(c) for c in df.columns])

print("✅ Nomes de colunas limpos:", df.columns)

# COMMAND ----------

catalog = "psa"   # catálogo do seu projeto
database = "bronze"
tabela = "logs_sistema"

df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .option("overwriteSchema", "true") \
    .saveAsTable(f"{catalog}.{database}.{tabela}")

print("✅ Dados gravados com sucesso em:", f"{catalog}.{database}.{tabela}")


# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail psa.bronze.logs_sistema
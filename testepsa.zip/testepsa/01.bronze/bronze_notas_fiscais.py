# Databricks notebook source
#import o controle de de data
from pyspark.sql.functions import current_date,current_timestamp, expr

# COMMAND ----------

 #criação de variavel 
 database ="bronze"
 tabela = "notas_fiscais"

# COMMAND ----------

#ESTABELECENDO DATAFRAME 
df = spark.table('psa.bronze.notas_fiscais')

# COMMAND ----------

display(df)

# COMMAND ----------

#incluir colunas de controle para saber a carga 
df = df.withColumn('data_carga',current_date())
df = df.withColumn('data_hora_carga',expr('current_timestamp()- interval 3 hours'))

# COMMAND ----------

#gravar os dados no formato delta
df.write \
    .format('delta') \
    .mode('overwrite') \
    .option('mergeSchema', 'true') \
    .option('overwriteSchema', 'true') \
    .saveAsTable(f'{database}.{tabela}')
print('Dados gravados com sucesso!')

# COMMAND ----------

# MAGIC %sql
# MAGIC describe detail psa.bronze.notas_fiscais
# MAGIC

# COMMAND ----------

# MAGIC %pip install spark-bigquery
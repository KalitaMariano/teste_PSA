# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC ## Informações Gerais
# MAGIC  | Informações | Detalhes |
# MAGIC  |------------|-------------|
# MAGIC  |Nome Tabela | silver.psa |
# MAGIC  |Origem | bronze.dados_clientes / bronze.notas_fiscais /bronze.analises_tributarias/ bronze.tarefas_projetos / bronze.logs_sistema |
# MAGIC
# MAGIC ## Histórico de Atualizações
# MAGIC  | Data | Desenvolvido por | Motivo |
# MAGIC  |:----:|--------------|--------|
# MAGIC  |27/10/2025 | Kálita Boni | Criação do notebook |
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 1) Fixar o catálogo
# MAGIC USE CATALOG psa;
# MAGIC
# MAGIC -- 2) Criar/usar o schema (sem repetir o catálogo aqui)
# MAGIC CREATE SCHEMA IF NOT EXISTS psa_curated;
# MAGIC USE SCHEMA psa_curated;
# MAGIC
# MAGIC -- 3) Conferir
# MAGIC SELECT current_catalog() AS catalog, current_schema() AS schema;
# MAGIC
# MAGIC -- (opcional) ver todos os schemas do catálogo
# MAGIC SHOW SCHEMAS IN psa;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE psa_curated.notas_fiscais AS
# MAGIC WITH bronze AS (
# MAGIC   SELECT
# MAGIC     TRIM(NumeroNota)                                   AS numero_nota,
# MAGIC     CAST(TO_DATE(TO_TIMESTAMP(DataEmissao)) AS DATE)   AS data_emissao,
# MAGIC     TRIM(ClienteID)                                    AS cliente_id,
# MAGIC     CAST(ValorTotal AS DECIMAL(18,2))                  AS valor_total,
# MAGIC     Impostos                                           AS impostos_raw,  -- STRING
# MAGIC     Itens                                              AS itens_raw      -- pode ser STRING/JSON
# MAGIC   FROM psa.bronze.notas_fiscais
# MAGIC   WHERE TRIM(NumeroNota) IS NOT NULL
# MAGIC ),
# MAGIC
# MAGIC /* tenta ler Impostos como JSON; se não for JSON, vai dar NULL (e tratamos depois) */
# MAGIC json_try AS (
# MAGIC   SELECT
# MAGIC     numero_nota, data_emissao, cliente_id, valor_total, itens_raw, impostos_raw,
# MAGIC     CAST(get_json_object(impostos_raw, '$.ISS')    AS DECIMAL(18,2)) AS iss_json,
# MAGIC     CAST(get_json_object(impostos_raw, '$.PIS')    AS DECIMAL(18,2)) AS pis_json,
# MAGIC     CAST(get_json_object(impostos_raw, '$.COFINS') AS DECIMAL(18,2)) AS cofins_json
# MAGIC   FROM bronze
# MAGIC ),
# MAGIC
# MAGIC /* fallback por REGEX quando Impostos não for JSON (ex.: XML/texto) */
# MAGIC impostos_ok AS (
# MAGIC   SELECT
# MAGIC     numero_nota, data_emissao, cliente_id, valor_total, itens_raw, impostos_raw,
# MAGIC     COALESCE(
# MAGIC       iss_json,
# MAGIC       CAST(REPLACE(REGEXP_EXTRACT(impostos_raw, '(?i)ISS[^0-9]*([0-9]+[\\.,]?[0-9]*)', 1), ',', '.') AS DECIMAL(18,2))
# MAGIC     ) AS iss,
# MAGIC     COALESCE(
# MAGIC       pis_json,
# MAGIC       CAST(REPLACE(REGEXP_EXTRACT(impostos_raw, '(?i)PIS[^0-9]*([0-9]+[\\.,]?[0-9]*)', 1), ',', '.') AS DECIMAL(18,2))
# MAGIC     ) AS pis,
# MAGIC     COALESCE(
# MAGIC       cofins_json,
# MAGIC       CAST(REPLACE(REGEXP_EXTRACT(impostos_raw, '(?i)COFINS[^0-9]*([0-9]+[\\.,]?[0-9]*)', 1), ',', '.') AS DECIMAL(18,2))
# MAGIC     ) AS cofins
# MAGIC   FROM json_try
# MAGIC ),
# MAGIC
# MAGIC curated AS (
# MAGIC   SELECT
# MAGIC     numero_nota,
# MAGIC     data_emissao,
# MAGIC     cliente_id,
# MAGIC     COALESCE(valor_total, CAST(0 AS DECIMAL(18,2))) AS valor_total,
# MAGIC     named_struct(
# MAGIC       'iss',   COALESCE(iss,    CAST(0 AS DECIMAL(18,2))),
# MAGIC       'pis',   COALESCE(pis,    CAST(0 AS DECIMAL(18,2))),
# MAGIC       'cofins',COALESCE(cofins, CAST(0 AS DECIMAL(18,2)))
# MAGIC     ) AS impostos_detalhados,
# MAGIC     itens_raw AS itens
# MAGIC   FROM impostos_ok
# MAGIC ),
# MAGIC
# MAGIC -- remove duplicatas por número da nota (mantém a mais recente por data)
# MAGIC dedup AS (
# MAGIC   SELECT * EXCEPT(rn) FROM (
# MAGIC     SELECT c.*,
# MAGIC            ROW_NUMBER() OVER (PARTITION BY numero_nota ORDER BY data_emissao DESC NULLS LAST) rn
# MAGIC     FROM curated c
# MAGIC   ) WHERE rn = 1
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   numero_nota,
# MAGIC   data_emissao,
# MAGIC   valor_total,
# MAGIC   impostos_detalhados,
# MAGIC   cliente_id,
# MAGIC   itens
# MAGIC FROM dedup;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE psa_curated.notas_fiscais_itens AS
# MAGIC WITH base AS (
# MAGIC   SELECT
# MAGIC     TRIM(NumeroNota)                                   AS numero_nota,
# MAGIC     CAST(TO_DATE(TO_TIMESTAMP(DataEmissao)) AS DATE)   AS data_emissao,
# MAGIC     TRIM(ClienteID)                                    AS cliente_id,
# MAGIC     Itens                                              AS itens_raw
# MAGIC   FROM psa.bronze.notas_fiscais
# MAGIC   WHERE TRIM(NumeroNota) IS NOT NULL
# MAGIC ),
# MAGIC
# MAGIC parsed AS (
# MAGIC   SELECT
# MAGIC     numero_nota, data_emissao, cliente_id,
# MAGIC     FROM_JSON(
# MAGIC       itens_raw,
# MAGIC       'STRUCT<Item:ARRAY<STRUCT<Descricao:STRING,Quantidade:INT,ValorUnitario:DECIMAL(18,2)>>>'
# MAGIC     ) AS itens_json
# MAGIC   FROM base
# MAGIC ),
# MAGIC
# MAGIC exploded AS (
# MAGIC   SELECT
# MAGIC     numero_nota, data_emissao, cliente_id,
# MAGIC     EXPLODE(itens_json.Item) AS item
# MAGIC   FROM parsed
# MAGIC   WHERE itens_json IS NOT NULL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   numero_nota,
# MAGIC   data_emissao,
# MAGIC   cliente_id,
# MAGIC   TRIM(item.Descricao)                                    AS descricao_item,
# MAGIC   COALESCE(CAST(item.Quantidade AS INT), 0)               AS quantidade,
# MAGIC   COALESCE(CAST(item.ValorUnitario AS DECIMAL(18,2)), CAST(0 AS DECIMAL(18,2))) AS valor_unitario,
# MAGIC   COALESCE(CAST(item.Quantidade AS INT), 0) *
# MAGIC   COALESCE(CAST(item.ValorUnitario AS DECIMAL(18,2)), CAST(0 AS DECIMAL(18,2))) AS valor_total_item
# MAGIC FROM exploded;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 0. Quais colunas existem e tipos?
# MAGIC DESCRIBE TABLE psa.bronze.notas_fiscais;
# MAGIC
# MAGIC -- 1. Total na Bronze
# MAGIC SELECT COUNT(*) FROM psa.bronze.notas_fiscais;
# MAGIC
# MAGIC -- 2. Quantas têm NumeroNota preenchido?
# MAGIC SELECT COUNT(*) 
# MAGIC FROM psa.bronze.notas_fiscais 
# MAGIC WHERE TRIM(NumeroNota) IS NOT NULL;
# MAGIC
# MAGIC -- 3. Prévia simples da Bronze (confirme nomes exatamente iguais)
# MAGIC SELECT NumeroNota, DataEmissao, ClienteID, ValorTotal, Impostos, Itens
# MAGIC FROM psa.bronze.notas_fiscais
# MAGIC LIMIT 5;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_catalog(), current_schema();
# MAGIC
# Databricks notebook source
# MAGIC %md
# MAGIC ## Informações Gerais
# MAGIC  | Informações | Detalhes |
# MAGIC  |------------|-------------|
# MAGIC  |Nome Tabela | silver.psa |
# MAGIC  |Origem | bronze.dados_clientes / bronze.notas_fiscais /bronze.analises_tributarias/ bronze.tarefas_projetos / bronze.logs_sistema |
# MAGIC
# MAGIC ## Histórico de Atualizações
# MAGIC  | Data | Desenvolvido por | Motivo |
# MAGIC  |:----:|--------------|--------|
# MAGIC  |27/10/2025 | Kálita Boni | Criação do notebook |
# MAGIC

# COMMAND ----------

# Importações
from pyspark.sql.functions import current_date, current_timestamp, expr

# COMMAND ----------

# Funções
#Função que aplica os comentários na tabela
def adicionaComentariosTabela(a,b,c,d):
    spark.sql(f"COMMENT ON TABLE {a}.{b} IS '{c}'")
    for key,value in d.items():
        sqlaux = f"ALTER TABLE {a}.{b} CHANGE COLUMN {key} COMMENT '{value}'"
        spark.sql(sqlaux)

# COMMAND ----------

database = "silver"
tabela = "psa_curated.clientes"

# COMMAND ----------

df_clientes_silver = spark.sql("""
WITH bronze AS (
    SELECT
        TRIM(id_cliente)                  AS id_cliente,
        TRIM(razao_social)                AS razao_social,
        TRIM(cnpj)                        AS cnpj_raw,
        TRIM(porte_empresa)               AS porte_empresa,
        TRIM(setor)                       AS setor,
        TRIM(cidade)                      AS cidade,
        UPPER(TRIM(estado))               AS estado,
        CAST(data_cadastro AS DATE)       AS data_cadastro
    FROM psa.bronze.dados_clientes
),

curated AS (
    SELECT
        id_cliente,
        -- Padroniza o nome (capitalização e substituição de “Ltda”)
        REGEXP_REPLACE(INITCAP(razao_social), 'Ltda', 'LTDA') AS razao_social,
        
        -- Limpa CNPJ (mantém apenas números)
        LPAD(REGEXP_REPLACE(cnpj_raw, '[^0-9]', ''), 14, '0') AS cnpj,
        
        -- Padroniza os textos
        INITCAP(porte_empresa) AS porte_empresa,
        INITCAP(setor)         AS setor,
        INITCAP(cidade)        AS cidade,
        estado,
        data_cadastro
    FROM bronze
    WHERE id_cliente IS NOT NULL
),

deduplicado AS (
    SELECT * EXCEPT(rn)
    FROM (
        SELECT
            c.*,
            ROW_NUMBER() OVER (
                PARTITION BY id_cliente
                ORDER BY data_cadastro DESC NULLS LAST
            ) AS rn
        FROM curated c
    )
    WHERE rn = 1
)

SELECT
    id_cliente,
    razao_social,
    cnpj,
    porte_empresa,
    setor,
    cidade,
    estado,
    data_cadastro
FROM deduplicado
""")

# Salva como tabela Silver
(df_clientes_silver.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .saveAsTable("psa_curated.clientes"))

print("✅ Camada Silver criada: psa_curated.clientes")


# COMMAND ----------

# Ver catálogos disponíveis
spark.sql("SHOW CATALOGS").show(truncate=False)

# Selecionar o catálogo que você está usando (pelo print, parece ser 'psa' ou 'workspace')
spark.sql("USE CATALOG psa")  # troque para 'workspace' ou 'hive_metastore' se for o seu caso

# Listar schemas
spark.sql("SHOW SCHEMAS").show(truncate=False)

# Explorar os schemas onde você criou as camadas
spark.sql("USE SCHEMA psa_curated")   # Silver
spark.sql("SHOW TABLES").show(truncate=False)

spark.sql("USE SCHEMA psa_raw")       # Bronze
spark.sql("SHOW TABLES").show(truncate=False)

spark.sql("USE SCHEMA psa_analytics") # Gold
spark.sql("SHOW TABLES").show(truncate=False)




# COMMAND ----------

# Ajuste o catálogo/esquema conforme o que você viu no passo 1
df_silver = spark.read.table("psa.psa_curated.clientes")   # Silver
df_bronze = spark.read.table("psa.psa_raw.clientes")       # Bronze

display(df_silver.limit(5))
display(df_bronze.limit(5))


# COMMAND ----------

# Exporte com cabeçalho
(df_silver
 .write
 .mode("overwrite")
 .option("header", True)
 .csv("/FileStore/tables/silver_clientes"))

(df_bronze
 .write
 .mode("overwrite")
 .option("header", True)
 .csv("/FileStore/tables/bronze_clientes"))

print("Links (abra no navegador logado no Databricks):")
print("Silver CSV → /files/tables/silver_clientes/")
print("Bronze CSV → /files/tables/bronze_clientes/")
